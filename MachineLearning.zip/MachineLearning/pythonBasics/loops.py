

# score = 0
#
# while (score <= 19):
#     print('Your score is: ', score)
#     score = score + 1
#
# print("Hello there")



# for i in 'HelloWorld':
#     print("THe letter is: ", i)


marvels = ['Deadpool', 'Thor', 'Hulk', 'Ironman', 'Spiderman']

for hero in marvels:
    print('Hero name is: ', hero)
