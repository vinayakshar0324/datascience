# print("Hello World!")


score = "HelloWorld!"

# print(score[2:])

mylist = ['hulk', 3.87, 'spiderman', 4]

print(mylist[1:3])

mytuple = ('text', 4.8)

mydict = {'name': 'superman', 'age': 40}

print(mydict.keys())
